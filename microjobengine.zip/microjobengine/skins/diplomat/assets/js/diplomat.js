(function($) {
    $(document).ready(function(){
        var slider = jQuery("#slider").mostSlider({
            aniMethod: 'auto',
        });
    });
})(jQuery);