<div class="post-job step-auth step-wrapper" id="step2">
<?php mJobAuthFormOnPage(); ?>
</div>
