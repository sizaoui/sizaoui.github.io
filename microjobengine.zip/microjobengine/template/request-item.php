<div class="<?php echo $current->mjob_class; ?>">
    <?php global $post; mjob_request_template($post);?>
</div>