<div class="text-description">
    <p class="title-description"><?php _e('Offer detail', 'enginethemes'); ?></p>
    <?php echo $mjob_order->offer_content; ?>
</div>

<div class="attachment-file-name">
    <?php echo $mjob_order->offer_attach_file; ?>
</div>