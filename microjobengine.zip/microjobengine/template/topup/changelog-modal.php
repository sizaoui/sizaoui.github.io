<div id="topup-changelog-dialog-wrapper" class="topup-changelog-dialog hidden">
    <div class="inner is-empty">
        <div class="spinner-wrapper">
            <span class="spinner"></span>
        </div>

        <div class="user-info hidden">
            <p>Username: <strong class="username"></strong></p>
            <p>Email: <strong class="useremail"></strong></p>
        </div>
    </div>
</div>