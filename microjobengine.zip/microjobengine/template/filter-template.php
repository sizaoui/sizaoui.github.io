<div class="filter-by">
    <select name="post_status">
        <option value=""><?php _e('All', 'enginethemes'); ?></option>
        <option value="pending"><?php _e('Pending', 'enginethemes'); ?></option>
        <option value="reject"><?php _e('Unapproved', 'enginethemes'); ?></option>
        <option value="active"><?php _e('Active', 'enginethemes'); ?></option>
        <option value="archive"><?php _e('Archived', 'enginethemes'); ?></option>
        <option value="pause"><?php _e('Pause', 'enginethemes'); ?></option>
        <option value="draft"><?php _e('Draft', 'enginethemes'); ?></option>
    </select>
</div>
<!--<div class="view-as">-->
<!--    <ul>-->
<!--        <span>View as</span>-->
<!--        <li class="grid"><i class="fa fa-th"></i></li>-->
<!--        <li class="list"><i class="fa fa-align-justify"></i></li>-->
<!--    </ul>-->
<!--</div>-->