<div class="filter-by">
    <select name="post_status" class="filter_status">
        <option value="0"><?php _e('All', 'enginethemes'); ?></option>
        <option value="pending"><?php _e('Pending', 'enginethemes'); ?></option>
        <option value="publish"><?php _e('Active', 'enginethemes'); ?></option>
        <option value="late"><?php _e('Late', 'enginethemes'); ?></option>
        <option value="delivery"><?php _e('Delivered', 'enginethemes'); ?></option>
        <option value="finished"><?php _e('Finished', 'enginethemes'); ?></option>
        <option value="disputing"><?php _e('Disputing', 'enginethemes'); ?></option>
        <option value="disputed"><?php _e('Resolved', 'enginethemes'); ?></option>
    </select>
</div>
<!--<div class="view-as">-->
<!--    <ul>-->
<!--        <span>View as</span>-->
<!--        <li class="grid"><i class="fa fa-th"></i></li>-->
<!--        <li class="list"><i class="fa fa-align-justify"></i></li>-->
<!--    </ul>-->
<!--</div>-->