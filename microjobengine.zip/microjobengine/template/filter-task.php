<div class="filter-by">
    <select name="post_status">
        <option value=""><?php _e('All', 'enginethemes'); ?></option>
        <option value="publish"><?php _e('Active', 'enginethemes'); ?></option>
        <option value="late"><?php _e('Late', 'enginethemes'); ?></option>
        <option value="delivery"><?php _e('Delivered', 'enginethemes'); ?></option>
        <option value="finished"><?php _e('Finished', 'enginethemes'); ?></option>
        <option value="disputing"><?php _e('Disputing', 'enginethemes'); ?></option>
        <option value="disputed"><?php _e('Resolved', 'enginethemes'); ?></option>
    </select>
</div>