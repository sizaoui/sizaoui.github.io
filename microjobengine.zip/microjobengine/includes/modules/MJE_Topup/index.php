<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

require_once 'class-mje-topup.php';
require_once 'class-mje-topup-table.php';