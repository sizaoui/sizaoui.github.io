<?php
require_once dirname(__FILE__) . '/class-mje-package-post-type.php';
require_once dirname(__FILE__) . '/class-mje-payment.php';