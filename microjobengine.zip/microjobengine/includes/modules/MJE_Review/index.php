<?php
require_once dirname(__FILE__) . '/class-mje-review.php';
require_once dirname(__FILE__) . '/class-mje-review-action.php';