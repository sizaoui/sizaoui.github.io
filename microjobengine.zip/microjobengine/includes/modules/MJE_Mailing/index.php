<?php
require_once dirname(__FILE__) . '/class-mje-mailing.php';
require_once dirname(__FILE__) . '/class-mje-mailing-action.php';