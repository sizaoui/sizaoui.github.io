<div class="modal fade" id="#decline-withdraw-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel1"><?php _e('Decline Withdraw', 'enginethemes'); ?></h4>
            </div>
            <div class="modal-body">
                <div class="form-control">
                    <textarea name="decline_note" id="decline_note" cols="30" rows="10" placeholder="<?php __('Give a decline reason to user', 'enginethemes'); ?>"></textarea>
                </div>

                <div class="form-control">
                    <button><?php __('Submit', 'enginethemes'); ?></button>
                </div>
            </div>
        </div>
    </div>
</div>