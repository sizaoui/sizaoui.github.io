<?php
require_once dirname(__FILE__) . '/module/index.php';
require_once dirname(__FILE__) . '/admin.php';
require_once dirname(__FILE__) . '/admin-action.php';