<?php
require_once dirname(__FILE__) . '/template/authTemplate.php';
require_once dirname(__FILE__) . '/template/form-authTemplate.php';
require_once dirname(__FILE__) . '/template/modal-authTemplate.php';
require_once dirname(__FILE__) . '/class-mJobUser.php';
require_once dirname(__FILE__) . '/class-mJobUserAction.php';
require_once dirname(__FILE__) . '/class-mJobConnectSocial.php';