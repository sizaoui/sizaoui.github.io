<?php
require_once dirname(__FILE__) . '/MJE_Admin/index.php';
require_once dirname(__FILE__) . '/mJobCustomOrder/index.php';
require_once dirname(__FILE__) . '/AE_Customizer/index.php';
require_once dirname(__FILE__) . '/MJE_Package/index.php';
require_once dirname(__FILE__) . '/AE_Taxonomy_Meta/index.php';
require_once dirname(__FILE__) . '/MJE_MJob_Order/index.php';
require_once dirname(__FILE__) . '/MJE_Review/index.php';
require_once dirname(__FILE__) . '/AE_Authentication/index.php';
require_once dirname(__FILE__) . '/MJE_Notification/index.php';
require_once dirname(__FILE__) . '/AE_VirtualWallet/index.php';
require_once dirname(__FILE__) . '/AE_Message/index.php';
require_once dirname(__FILE__) . '/MJE_Profile/index.php';
require_once dirname(__FILE__) . '/MJE_MJob/index.php';
require_once dirname(__FILE__) . '/MJE_Conversation/index.php';
require_once dirname(__FILE__) . '/MJE_Skins/index.php';
require_once dirname(__FILE__) . '/MJE_Topup/index.php';
require_once dirname(__FILE__) . '/Mje_Ban_User/index.php';
