https://semantic-ui.com/
Javascript Opensouce AIP for dropdown field.