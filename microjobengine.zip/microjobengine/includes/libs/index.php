<?php
require_once dirname(__FILE__) . '/wp_bootstrap_navwalker.php';