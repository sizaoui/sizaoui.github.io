<div class="sort-handle col-md-1 col-sm-1"><i class="fa fa-database" aria-hidden="true"></i>{{= sku }}</div>
<div class="col-md-3 col-sm-3"><span>{{= post_title }}</span></div>
<div class="col-md-2 col-sm-2">{{= package_price }}</div>
<div class="col-md-2 col-sm-2">{{= package_duration }}</div>
<div class="col-md-2 col-sm-2">{{= et_number_posts }}</div>
<div class="actions col-md-1">
	<a href="#" title="Edit" class="icon act-edit" rel="665"><i class="fa fa-pencil" aria-hidden="true"></i></a>
	<a href="#" title="Delete" class="icon act-del" rel="665"><i class="fa fa-times" aria-hidden="true"></i></a>
</div>					
<div class="clearfix"></div>